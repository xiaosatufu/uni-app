<template>
  <div>
    <div class="m-header-btns"></div>
    <div class="table-filters"></div>
    <div class="m-table"></div>
  </div>
</template>

<script>
import { poiList, user, comments } from "@/api/poi";
export default {
  mounted() {
    this.loadPoiList();
  },
  methods: {
    loadPoiList() {
      user().then(res => {
        console.log(res);
      });
      poiList().then(res => {
        console.log(res);
      });
      comments().then(res => {
        console.log(res);
      });
    }
  }
};
</script>

<style lang="scss" scoped>
</style>