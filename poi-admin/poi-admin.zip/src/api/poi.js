import request from '@/utils/request'

export function poiList() {
    return request({
        url: 'http://test-liuwa.hupovip.net/poi/admin',
        method: 'get'
    })
}


export function user(){
    return request({
        url:'http://test-liuwa.hupovip.net/user',
        method:'get'
    })
}
export function comments(){
    return request({
        url:'http://test-liuwa.hupovip.net/comments',
        method:'get'
    })
}